README 

----------------------------------------------------
	OptinSkin README for Exported Skin
----------------------------------------------------
Generated on April 15, 2015, 4:33 pm 

- The HTML code for your skin is located in the /html folder, and the stylesheet in the /css folder.
- An index.html file exists in this directory, which you can use to check that your skin is displaying correctly.
- You can use the index.html file to see how to embed your skin into a web page.